# Test Automation with Template Matching and BDD
## Student Learning Guide

---

## 📚 Table of Contents
1. [Introduction](#introduction)
2. [Part 1: Understanding Template Matching](#part-1-template-matching)
3. [Part 2: Introduction to BDD Testing](#part-2-bdd-testing)

---

## Introduction

### What You Will Learn
By the end of this tutorial, you will be able to:
- ✅ Understand how template matching works with OpenCV
- ✅ Write BDD test scenarios in Gherkin language
- ✅ Create automated UI tests using image recognition
- ✅ Build a complete test automation framework
- ✅ Test real Windows applications without code access

### Prerequisites
- Basic Python knowledge
- Understanding of software testing concepts
- Windows operating system
- Text editor (VS Code recommended)

### Why This Matters
Modern applications often have complex UIs that are difficult to test with traditional automation tools. Template matching allows you to:
- Test any application (even legacy or proprietary software)
- Verify visual appearance and layout
- Automate tasks without accessing source code
- Create maintainable tests using BDD approach

### Install Dependencies
```
pip install -r requirements.txt
```

### Project Structure
```
project/
├── automation_library.py          # Core OpenCV automation
├── calculator_automation.py       # Calculator-specific
├── template_helper.py             # Script to create 
├── requirements.txt
├── templates/
│   └── calculator/
│       ├── button_0.png
│       ├── button_1.png
│       ├── button_2.png
│       ├── ...
│       ├── button_plus.png
│       ├── button_equals.png
│       └── ...
└── features/
    ├── calculator.feature
    ├── environment.py
    └── steps/
        └── calculator_steps.py
```

## Key Features

### Template Matching Methods
- **find_template()** - Find single occurrence
- **find_all_templates()** - Find all occurrences
- **wait_for_template()** - Wait until template appears
- **click_template()** - Click on template
- **verify_template_exists()** - Boolean check

### Automation Actions
- Click, double-click, right-click
- Hover over elements
- Drag and drop between templates
- Type text and press keys
- Keyboard shortcuts

### Advanced Features
- Multi-scale template matching
- Non-maximum suppression for overlapping matches
- Confidence threshold adjustment
- Region-based searching for performance
- Screenshot capture on test failure
- Template highlighting for debugging
---

## Part 1: Template Matching

### 1.1 What is Template Matching?

**Template matching** is a computer vision technique that finds areas of an image that match a template image.

**Simple Analogy:**
Think of it like a "Where's Waldo?" puzzle:
- **Template**: Picture of Waldo you're looking for
- **Screen**: The full page with many people
- **Matching**: Finding Waldo's location on the page

### 1.2 How Template Matching Works

```
Step 1: Capture Screenshot
┌─────────────────────────────┐
│                             │
│    [Screen Content]         │
│                             │
└─────────────────────────────┘

Step 2: Load Template Image
┌──────┐
│ [5]  │  ← Button template
└──────┘

Step 3: Slide Template Across Screen
┌─────────────────────────────┐
│  ┌──────┐                   │
│  │ [5]  │ Compare here      │
│  └──────┘                   │
│     ┌──────┐                │
│     │ [5]  │ Compare here   │
│     └──────┘                │
└─────────────────────────────┘

Step 4: Find Best Match
┌─────────────────────────────┐
│         ✓ MATCH!            │
│        ┌──────┐             │
│        │ [5]  │ 95%         │
│        └──────┘             │
└─────────────────────────────┘
```

### 1.3 OpenCV Template Matching

**OpenCV** (Open Source Computer Vision Library) provides the `matchTemplate()` function:

```python
import cv2
import numpy as np

# Load images
screenshot = cv2.imread('screen.png')
template = cv2.imread('button.png')

# Perform template matching
result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)

# Find best match location
min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

print(f"Match confidence: {max_val * 100:.1f}%")
print(f"Location: {max_loc}")
```

### 1.4 Confidence Threshold

**Confidence** = How similar the template is to the found region (0.0 to 1.0)

```
0.0 - 0.5  → Poor match (likely wrong)
0.5 - 0.7  → Moderate match (might be correct)
0.7 - 0.9  → Good match (probably correct)
0.9 - 1.0  → Excellent match (almost certain)
```

**Example:**
```python
confidence_threshold = 0.8  # Require 80% similarity

if max_val >= confidence_threshold:
    print("✓ Button found!")
else:
    print("✗ Button not found")
```

### 1.5 Practical Exercise 1

**Task:** Create a simple template matcher

```python
import cv2
import pyautogui
import numpy as np

def find_button():
    # 1. Take screenshot
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    # 2. Load template
    template = cv2.imread('templates/button_5.png')
    
    # 3. Match
    result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    
    # 4. Display result
    print(f"Found with {max_val*100:.1f}% confidence at {max_loc}")
    
    return max_loc if max_val > 0.8 else None

# Try it
location = find_button()
if location:
    print(f"✓ Button at position: {location}")
```

**Your Turn:**
1. Open Calculator on Windows
2. Take a screenshot of the number "5" button
3. Save it as `button_5.png`
4. Run the code above
5. Observer the confidence score

---

## Part 2: BDD Testing

### 2.1 What is BDD?

**BDD** = Behavior-Driven Development

**Key Concept:** Write tests in plain English that everyone can understand!

**Traditional Test:**
```python
def test_addition():
    calc.click(5)
    calc.click('+')
    calc.click(3)
    calc.click('=')
    assert calc.result() == 8
```

**BDD Test:**
```gherkin
Scenario: Add two numbers
  Given the calculator is open
  When I enter "5" plus "3"
  And I press equals
  Then the result should be "8"
```

### 2.2 Gherkin Language

**Gherkin** is the language used to write BDD scenarios.

**Keywords:**
- `Feature:` - Group of related scenarios
- `Scenario:` - A specific test case
- `Given` - Initial state / preconditions
- `When` - Action / event
- `And` - Additional steps
- `Then` - Expected outcome / assertion

**Structure:**
```gherkin
Feature: Feature name
  Description of feature

  Scenario: Scenario name
    Given [precondition]
    When [action]
    And [additional action]
    Then [expected result]
```

### 2.3 BDD Benefits

| Traditional Testing | BDD Testing |
|-------------------|-------------|
| Code-focused | Behavior-focused |
| Technical language | Plain English |
| Developers only | Everyone understands |
| Hard to maintain | Easy to update |
| No documentation | Self-documenting |

### 2.4 Writing Good Scenarios

**❌ Bad Scenario:**
```gherkin
Scenario: Test buttons
  Given app is open
  When I click stuff
  Then it works
```

**✅ Good Scenario:**
```gherkin
Scenario: Calculate sum of two numbers
  Given the Calculator application is open
  When I enter "5" plus "3"
  And I press equals
  Then the result should be "8"
```

**Tips for Good Scenarios:**
1. **Specific**: Exact inputs and outputs
2. **Readable**: Non-technical person can understand
3. **Testable**: Clear pass/fail criteria
4. **Independent**: Don't depend on other scenarios
5. **Focused**: Test one thing at a time
