from calculator_automation import CalculatorImageAutomation

# Open calculator and manually capture buttons
calc = CalculatorImageAutomation()
calc.open_calculator()

# Capture a button (adjust coordinates for your screen)
calc.create_template_from_region('button_1', x=283, y=700, width=100, height=44)
calc.create_template_from_region('button_2', x=388, y=700, width=100, height=44)
calc.create_template_from_region('button_3', x=492, y=700, width=100, height=44)
calc.create_template_from_region('button_4', x=283, y=636, width=100, height=44)
calc.create_template_from_region('button_5', x=386, y=636, width=100, height=44)
calc.create_template_from_region('button_6', x=493, y=636, width=100, height=44)
calc.create_template_from_region('button_7', x=283, y=568, width=100, height=44)
calc.create_template_from_region('button_8', x=386, y=568, width=100, height=44)
calc.create_template_from_region('button_9', x=493, y=568, width=100, height=44)
calc.create_template_from_region('button_0', x=386, y=764, width=100, height=44)
calc.create_template_from_region('button_plus', x=594, y=698, width=100, height=44)
calc.create_template_from_region('button_minus', x=594, y=633, width=100, height=44)
calc.create_template_from_region('button_multiply', x=594, y=568, width=100, height=44)
calc.create_template_from_region('button_divide', x=594, y=508, width=100, height=44)
calc.create_template_from_region('button_equals', x=594, y=764, width=100, height=44)
calc.create_template_from_region('button_clear', x=492, y=439, width=100, height=44)
calc.create_template_from_region('button_clear_entry', x=392, y=435, width=100, height=44)
calc.create_template_from_region('button_decimal', x=490, y=762, width=100, height=44)

# Close calculator when done
calc.close_calculator()
