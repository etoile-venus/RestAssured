from template_helper import TemplateCreator

template_helper = TemplateCreator()
template_helper.create_calculator_templates()