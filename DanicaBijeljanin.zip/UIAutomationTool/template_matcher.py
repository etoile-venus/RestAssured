import cv2
import pyautogui
import numpy as np
import os
print(os.path.exists('templates/calculator/button_5.png'))


def find_button():
    # 1. Napravi screenshot ekrana
    screenshot = pyautogui.screenshot()
    screenshot = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    
    # 2. Učitaj template dugmeta
    template = cv2.imread('templates/calculator/button_5.png')
    if template is None:
        print("✗ Template image not found! Make sure templates/calculator/button_5.png exists")
        return None
    
    # 3. Pokreni template matching
    result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    
    # 4. Prikazi rezultat u terminalu
    print(f"Found with {max_val*100:.1f}% confidence at {max_loc}")
    
    # 5. Vrati lokaciju ako je confidence veći od 0.8
    return max_loc if max_val > 0.8 else None

# Pokreni funkciju
location = find_button()
if location:
    print(f"✓ Button found at position: {location}")
else:
    print("✗ Button not found")
