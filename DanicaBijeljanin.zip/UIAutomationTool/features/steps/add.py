"""
Complete Step Implementations for add.feature Test
"""

from behave import given, when, then
from calculator_automation import CalculatorImageAutomation
import time
import logging

logger = logging.getLogger(__name__)

@given('the Calculator application is open')
def step_given_calculator_open(context):
    """
    Open the calculator application and verify it's ready
    """
    logger.info("GIVEN: Opening Calculator application")
    
    if not hasattr(context, 'calculator'):
        context.calculator = CalculatorImageAutomation(
            templates_dir="templates/calculator",
            confidence=0.8
        )
    
    success = context.calculator.open_calculator()
    
    assert success, "Failed to open Calculator application"
    
    calculator_ready = context.calculator.wait_for_template('button_1', timeout=5)
    assert calculator_ready, "Calculator opened but UI not ready"
    
    logger.info("✓ Calculator is open and ready")


@when('I enter "{first_number}" plus "{second_number}"')
def step_when_enter_addition(context, first_number, second_number):
    """
    Enter two numbers with plus operator
    Example: When I enter "5" plus "3"
    """
    logger.info(f"WHEN: Entering {first_number} + {second_number}")
    
    calc = context.calculator
    
    for digit in first_number:
        success = calc.click_number(digit)
        assert success, f"Failed to click number: {digit}"
        time.sleep(0.2)  # Small delay between clicks
    
    success = calc.click_operator('+')
    assert success, "Failed to click plus operator"
    time.sleep(0.2)
    
    for digit in second_number:
        success = calc.click_number(digit)
        assert success, f"Failed to click number: {digit}"
        time.sleep(0.2)
    
    context.expression = f"{first_number} + {second_number}"
    
    logger.info(f"✓ Entered expression: {context.expression}")


@when('I press equals')
def step_when_press_equals(context):
    """
    Press the equals button to execute calculation
    """
    logger.info("WHEN: Pressing equals button")
    
    calc = context.calculator

    success = calc.click_operator('=')
    assert success, "Failed to click equals button"
    
    time.sleep(0.5)
    
    logger.info("✓ Pressed equals button")



@then('the result should be "{expected_result}"')
def step_then_result_should_be(context, expected_result):
    """
    Verify the calculator displays the expected result
    This implementation uses OCR or visual verification
    """
    logger.info(f"THEN: Verifying result is {expected_result}")
    
    calc = context.calculator
    
    result_template = f"result_{expected_result}"
    result_visible = calc.wait_for_template(result_template, timeout=5)
    assert result_visible, f"Expected result '{expected_result}' not visible on screen" 

@when('I enter "{number}"')
def step_enter_number(context, number):
    """
    Enter a number (single or multi-digit)
    Example: When I enter "5"
    """
    calc = context.calculator
    for digit in number:
        success = calc.click_number(digit)
        assert success, f"Failed to click number: {digit}"

@when('apply "{operation}"')
def step_press_operator(context, operation):
    """
    Click the operator button
    Example: When I apply "plus"
             When I apply "minus"
    """
    calc = context.calculator
    
    operation_map = {
        "plus": "+",
        "minus": "-",
        "multiply": "*",
        "divide": "/"
    }
    
    operator = operation_map.get(operation.lower())
    assert operator is not None, f"Unsupported operation: {operation}"
    
    success = calc.click_operator(operator)
    assert success, f"Failed to click operator: {operator}"


@when('I click button "{digit}"')
def step_click_button(context, digit):
    """
    Click a single calculator button by its label (number or operator)
    Example: When I click button "9"
    """
    calc = context.calculator
    success = calc.click_number(digit)
    assert success, f"Failed to click button: {digit}"

@when('I clear the calculator')
def step_clear_calculator(context):
    """
    Clear the calculator using the clear button
    """
    calc = context.calculator
    
    success = calc.click_template('button_clear')
    
    assert success, "Failed to clear the calculator"


@then('the calculator should be cleared')
def step_verify_cleared(context):
    """
    Verify calculator display is cleared (usually '0')
    """
    calc = context.calculator
    cleared = calc.wait_for_template('result_0', timeout=3)  
    assert cleared, "Calculator is not cleared"

@then('the number buttons should be visible')
def step_then_number_buttons_visible(context):
    """
    Verify that number buttons (0-9) are visible on the calculator UI
    """
    calc = context.calculator
    for digit in range(10):
        template_name = f"button_{digit}"
        visible = calc.wait_for_template(template_name, timeout=2)
        assert visible, f"Number button '{digit}' not visible"
    logger.info("✓ All number buttons are visible")

@then('the operator buttons should be visible')
def step_then_operator_buttons_visible(context):
    """
    Verify that operator buttons (+, -, *, /, =) are visible
    """
    calc = context.calculator
    operator_map = {
        '+': 'plus',
        '-': 'minus',
        '*': 'multiply',
        '/': 'divide',
        '=': 'equals'
    }
    for op_symbol, template_name in operator_map.items():
        visible = calc.wait_for_template(f"button_{template_name}", timeout=2)
        assert visible, f"Operator button '{op_symbol}' not visible"
    logger.info("✓ All operator buttons are visible")
