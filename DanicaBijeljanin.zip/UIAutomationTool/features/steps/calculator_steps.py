from behave import when

@when('I enter decimal number "{number}"')
def step_enter_decimal_number(context, number):
    """
    Enter a decimal number (e.g., "5.5", "10.75")
    
    Example usage:
        When I enter decimal number "5.5"
    """
    calc = context.calculator

    parts = number.split(".")
    integer_part = parts[0]
    decimal_part = parts[1] if len(parts) > 1 else ""

    for digit in integer_part:
        success = calc.click_number(digit)
        assert success, f"Failed to click number: {digit}"

    if decimal_part:
        success = calc.click_decimal()
        assert success, "Failed to click decimal point"

        for digit in decimal_part:
            success = calc.click_number(digit)
            assert success, f"Failed to click number: {digit}"



@when('I {operation} "{number}"')
def step_chain_operation(context, operation, number):
    """
    Perform operation on current result
    
    Example usage:
        When I multiply "2"
        When I plus "5"
    """
    calc = context.calculator

    operation_map = {
        "plus": "+",
        "minus": "-",
        "multiply": "*",
        "divide": "/"
    }

    operator = operation_map.get(operation.lower())
    assert operator is not None, f"Unsupported operation: {operation}"

    success = calc.click_operator(operator)
    assert success, f"Failed to click operator: {operator}"

    if "." in number:
        parts = number.split(".")
        for digit in parts[0]:
            success = calc.click_number(digit)
            assert success, f"Failed to click number: {digit}"
        success = calc.click_decimal()
        assert success, "Failed to click decimal point"
        for digit in parts[1]:
            success = calc.click_number(digit)
            assert success, f"Failed to click number: {digit}"
    else:
        for digit in number:
            success = calc.click_number(digit)
            assert success, f"Failed to click number: {digit}"

