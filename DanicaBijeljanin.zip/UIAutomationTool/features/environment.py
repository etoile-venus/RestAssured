import logging
import time

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def before_all(context):
    """Setup before all tests"""
    logger.info("="*60)
    logger.info("Starting Calculator Test Suite")
    logger.info("="*60)


def before_scenario(context, scenario):
    """Setup before each scenario"""
    logger.info(f"\n▶ Starting: {scenario.name}")


def after_scenario(context, scenario):
    """Cleanup after each scenario"""
    logger.info(f"◀ Finished: {scenario.name} - Status: {scenario.status}")
    
    # Take screenshot on failure
    if scenario.status == "failed":
        if hasattr(context, 'calculator'):
            filename = f"failed_{scenario.name.replace(' ', '_')}.png"
            context.calculator.save_screenshot(filename)
            logger.error(f"Screenshot saved: {filename}")
    
    # Close calculator
    if hasattr(context, 'calculator'):
        context.calculator.close_calculator()
        time.sleep(1)


def after_all(context):
    """Cleanup after all tests"""
    logger.info("="*60)
    logger.info("Test Suite Complete")
    logger.info("="*60)