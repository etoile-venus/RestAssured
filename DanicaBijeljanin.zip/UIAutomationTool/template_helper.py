"""
Helper script to create calculator button templates
Run this script with calculator open to capture button images
"""

import cv2
import pyautogui
import time
from pathlib import Path


class TemplateCreator:
    """Helper to create template images"""
    
    def __init__(self, output_dir="templates/calculator"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def capture_region(self, template_name, instructions):
        """
        Capture a region as a template
        User clicks two points to define region
        """
        print(f"\n{instructions}")
        print(f"Creating template: {template_name}")
        print("Move mouse to TOP-LEFT corner of region and press SPACE...")
        
        # Wait for spacebar
        import keyboard
        keyboard.wait('space')
        x1, y1 = pyautogui.position()
        print(f"Top-left: ({x1}, {y1})")
        
        print("Move mouse to BOTTOM-RIGHT corner and press SPACE...")
        keyboard.wait('space')
        x2, y2 = pyautogui.position()
        print(f"Bottom-right: ({x2}, {y2})")
        
        # Calculate region
        x = min(x1, x2)
        y = min(y1, y2)
        width = abs(x2 - x1)
        height = abs(y2 - y1)
        
        # Capture
        time.sleep(0.5)
        screenshot = pyautogui.screenshot(region=(x, y, width, height))
        
        # Save
        filepath = self.output_dir / f"{template_name}.png"
        screenshot.save(filepath)
        print(f"✓ Template saved: {filepath}")
        
        time.sleep(0.5)
    
    def create_calculator_templates(self):
        """Create all calculator button templates"""
        print("="*60)
        print("CALCULATOR TEMPLATE CREATOR")
        print("="*60)
        print("\nMake sure Windows Calculator is OPEN and VISIBLE")
        print("Press ENTER to continue...")
        input()
        
        # Define buttons to capture
        buttons = [
            ('button_0', 'Number button 0'),
            ('button_1', 'Number button 1'),
            ('button_2', 'Number button 2'),
            ('button_3', 'Number button 3'),
            ('button_4', 'Number button 4'),
            ('button_5', 'Number button 5'),
            ('button_6', 'Number button 6'),
            ('button_7', 'Number button 7'),
            ('button_8', 'Number button 8'),
            ('button_9', 'Number button 9'),
            ('button_plus', 'Plus (+) button'),
            ('button_minus', 'Minus (-) button'),
            ('button_multiply', 'Multiply (x) button'),
            ('button_divide', 'Divide (÷) button'),
            ('button_equals', 'Equals (=) button'),
            ('button_clear', 'Clear (C) button'),
            ('button_clear_entry', 'Clear Entry (CE) button'),
            ('button_decimal', 'Decimal point (.) button'),
        ]
        
        for template_name, description in buttons:
            self.capture_region(template_name, f"Capture: {description}")
        
        print("\n" + "="*60)
        print("✓ All templates created successfully!")
        print(f"Templates saved in: {self.output_dir}")
        print("="*60)