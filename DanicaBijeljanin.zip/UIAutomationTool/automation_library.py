"""
OpenCV Template Matching Test Automation Library
For BDD test automation using image recognition
"""

import cv2
import numpy as np
import pyautogui
import time
import logging
from pathlib import Path
from typing import Tuple, Optional, List

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configure PyAutoGUI
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.3


class ImageAutomation:
    """Image-based automation using OpenCV template matching"""
    
    def __init__(self, templates_dir="templates", confidence=0.8):
        """
        Initialize image automation
        Args:
            templates_dir: Directory containing template images
            confidence: Minimum confidence for template matching (0.0-1.0)
        """
        self.templates_dir = Path(templates_dir)
        self.confidence = confidence
        self.last_match = None
        self.screen_width, self.screen_height = pyautogui.size()
        
        # Create templates directory if it doesn't exist
        self.templates_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"ImageAutomation initialized - Screen: {self.screen_width}x{self.screen_height}")
    
    def capture_screenshot(self, region=None):
        """
        Capture screenshot as OpenCV image
        Args:
            region: Tuple (x, y, width, height) for partial screenshot
        Returns:
            OpenCV image in BGR format
        """
        screenshot = pyautogui.screenshot(region=region)
        # Convert PIL image to OpenCV format (BGR)
        screenshot_cv = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        return screenshot_cv
    
    def load_template(self, template_name):
        """
        Load template image
        Args:
            template_name: Name of template file (with or without extension)
        Returns:
            OpenCV image or None
        """
        # Try with and without .png extension
        if not template_name.endswith('.png'):
            template_path = self.templates_dir / f"{template_name}.png"
        else:
            template_path = self.templates_dir / template_name
        
        if not template_path.exists():
            logger.error(f"Template not found: {template_path}")
            return None
        
        template = cv2.imread(str(template_path))
        if template is None:
            logger.error(f"Failed to load template: {template_path}")
        return template
    
    def find_template(self, template_name, screenshot=None, threshold=None):
        """
        Find template on screen using template matching
        Args:
            template_name: Name of template image
            screenshot: Pre-captured screenshot (if None, captures new)
            threshold: Confidence threshold (uses default if None)
        Returns:
            Tuple (x, y, width, height, confidence) or None
        """
        logger.info(f"Looking for template: {template_name}")
        
        # Load template
        template = self.load_template(template_name)
        if template is None:
            return None
        
        # Capture screenshot if not provided
        if screenshot is None:
            screenshot = self.capture_screenshot()
        
        # Get template dimensions
        template_height, template_width = template.shape[:2]
        
        # Use default confidence if not specified
        if threshold is None:
            threshold = self.confidence
        
        # Perform template matching
        result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
        
        logger.info(f"Template match confidence: {max_val:.3f}")
        
        if max_val >= threshold:
            # Calculate center point
            x = max_loc[0] + template_width // 2
            y = max_loc[1] + template_height // 2
            
            self.last_match = {
                'x': x,
                'y': y,
                'width': template_width,
                'height': template_height,
                'confidence': max_val,
                'template': template_name
            }
            
            logger.info(f"Template found at ({x}, {y}) with confidence {max_val:.3f}")
            return (x, y, template_width, template_height, max_val)
        else:
            logger.warning(f"Template not found (confidence {max_val:.3f} < {threshold})")
            return False
    
    def find_all_templates(self, template_name, screenshot=None, threshold=None):
        """
        Find all occurrences of a template
        Args:
            template_name: Name of template image
            screenshot: Pre-captured screenshot (if None, captures new)
            threshold: Confidence threshold
        Returns:
            List of tuples [(x, y, width, height, confidence), ...]
        """
        logger.info(f"Looking for all occurrences of: {template_name}")
        
        template = self.load_template(template_name)
        if template is None:
            return []
        
        if screenshot is None:
            screenshot = self.capture_screenshot()
        
        if threshold is None:
            threshold = self.confidence
        
        template_height, template_width = template.shape[:2]
        
        # Perform template matching
        result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
        
        # Find all matches above threshold
        locations = np.where(result >= threshold)
        matches = []
        
        for pt in zip(*locations[::-1]):
            x = pt[0] + template_width // 2
            y = pt[1] + template_height // 2
            confidence = result[pt[1], pt[0]]
            matches.append((x, y, template_width, template_height, confidence))
        
        # Remove overlapping matches (non-maximum suppression)
        matches = self._non_max_suppression(matches, template_width, template_height)
        
        logger.info(f"Found {len(matches)} occurrences")
        return matches
    
    def _non_max_suppression(self, matches, width, height, overlap_threshold=0.5):
        """Remove overlapping matches, keep highest confidence"""
        if len(matches) == 0:
            return []
        
        # Sort by confidence
        matches = sorted(matches, key=lambda x: x[4], reverse=True)
        
        filtered = []
        for match in matches:
            x, y, w, h, conf = match
            
            # Check if this match overlaps with any already added
            overlaps = False
            for existing in filtered:
                ex, ey, ew, eh, _ = existing
                
                # Calculate overlap
                x_overlap = max(0, min(x + w//2, ex + ew//2) - max(x - w//2, ex - ew//2))
                y_overlap = max(0, min(y + h//2, ey + eh//2) - max(y - h//2, ey - eh//2))
                
                overlap_area = x_overlap * y_overlap
                match_area = w * h
                
                if overlap_area > match_area * overlap_threshold:
                    overlaps = True
                    break
            
            if not overlaps:
                filtered.append(match)
        
        return filtered
    
    def wait_for_template(self, template_name, timeout=10, interval=0.5):
        """
        Wait for template to appear on screen
        Args:
            template_name: Template to wait for
            timeout: Maximum time to wait in seconds
            interval: Time between checks in seconds
        Returns:
            Match tuple or None if timeout
        """
        logger.info(f"Waiting for template: {template_name} (timeout: {timeout}s)")
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            match = self.find_template(template_name)
            if match:
                return match
            time.sleep(interval)
        
        logger.warning(f"Timeout waiting for template: {template_name}")
        return None
    
    def click_template(self, template_name, offset_x=0, offset_y=0, clicks=1, button='left'):
        """
        Find and click on template
        Args:
            template_name: Template to click
            offset_x, offset_y: Click offset from center
            clicks: Number of clicks (1=single, 2=double)
            button: 'left', 'right', or 'middle'
        Returns:
            True if clicked, False if template not found
        """
        logger.info(f"Attempting to click template: {template_name}")
        
        match = self.find_template(template_name)
        if match:
            x, y, width, height, confidence = match
            click_x = x + offset_x
            click_y = y + offset_y
            
            logger.info(f"Clicking at ({click_x}, {click_y})")
            pyautogui.click(click_x, click_y, clicks=clicks, button=button)
            return True
        
        return False
    
    def double_click_template(self, template_name, offset_x=0, offset_y=0):
        """Double-click on template"""
        return self.click_template(template_name, offset_x, offset_y, clicks=2)
    
    def right_click_template(self, template_name, offset_x=0, offset_y=0):
        """Right-click on template"""
        return self.click_template(template_name, offset_x, offset_y, button='right')
    
    def hover_template(self, template_name, offset_x=0, offset_y=0, duration=1):
        """
        Move mouse to template without clicking
        Args:
            template_name: Template to hover over
            offset_x, offset_y: Offset from center
            duration: Time to move in seconds
        """
        logger.info(f"Hovering over template: {template_name}")
        
        match = self.find_template(template_name)
        if match:
            x, y, width, height, confidence = match
            pyautogui.moveTo(x + offset_x, y + offset_y, duration=duration)
            return True
        return False
    
    def drag_template_to_template(self, source_template, target_template, duration=1):
        """
        Drag from source template to target template
        Args:
            source_template: Template to drag from
            target_template: Template to drag to
            duration: Time to complete drag
        """
        logger.info(f"Dragging from {source_template} to {target_template}")
        
        source = self.find_template(source_template)
        if not source:
            logger.error(f"Source template not found: {source_template}")
            return False
        
        target = self.find_template(target_template)
        if not target:
            logger.error(f"Target template not found: {target_template}")
            return False
        
        source_x, source_y = source[0], source[1]
        target_x, target_y = target[0], target[1]
        
        pyautogui.moveTo(source_x, source_y)
        time.sleep(0.2)
        pyautogui.dragTo(target_x, target_y, duration=duration)
        
        return True
    
    def type_text(self, text, interval=0.05):
        """
        Type text at current cursor position
        Args:
            text: Text to type
            interval: Delay between keystrokes
        """
        logger.info(f"Typing text: {text}")
        pyautogui.typewrite(text, interval=interval)
    
    def press_key(self, key):
        """Press a single key"""
        logger.info(f"Pressing key: {key}")
        pyautogui.press(key)
    
    def hotkey(self, *keys):
        """Press keyboard shortcut"""
        logger.info(f"Pressing hotkey: {'+'.join(keys)}")
        pyautogui.hotkey(*keys)
    
    def verify_template_exists(self, template_name, threshold=None):
        """
        Verify template exists on screen
        Returns:
            Boolean
        """
        match = self.find_template(template_name, threshold=threshold)
        return match is not None
    
    def verify_template_not_exists(self, template_name, threshold=None):
        """
        Verify template does NOT exist on screen
        Returns:
            Boolean
        """
        match = self.find_template(template_name, threshold=threshold)
        return match is None
    
    def save_screenshot(self, filename="screenshot.png", region=None):
        """
        Save screenshot to file
        Args:
            filename: Output filename
            region: Tuple (x, y, width, height) for partial screenshot
        """
        logger.info(f"Saving screenshot: {filename}")
        screenshot = self.capture_screenshot(region)
        cv2.imwrite(filename, screenshot)
        return filename
    
    def create_template_from_region(self, template_name, x, y, width, height):
        """
        Capture a region of screen as a template
        Args:
            template_name: Name for the template
            x, y: Top-left corner
            width, height: Region size
        """
        logger.info(f"Creating template: {template_name} from region ({x},{y},{width},{height})")
        
        self.templates_dir.mkdir(parents=True, exist_ok=True)

        screenshot = self.capture_screenshot(region=(x, y, width, height))
        template_path = self.templates_dir / f"{template_name}.png"
        
        cv2.imwrite(str(template_path), screenshot)
        logger.info(f"Template saved: {template_path}")
        return str(template_path)
    
    def highlight_match(self, screenshot, match, color=(0, 255, 0), thickness=2):
        """
        Draw rectangle around match on screenshot (for debugging)
        Args:
            screenshot: OpenCV image
            match: Match tuple (x, y, width, height, confidence)
            color: BGR color tuple
            thickness: Line thickness
        Returns:
            Screenshot with rectangle drawn
        """
        if match:
            x, y, width, height = match[0], match[1], match[2], match[3]
            top_left = (x - width // 2, y - height // 2)
            bottom_right = (x + width // 2, y + height // 2)
            cv2.rectangle(screenshot, top_left, bottom_right, color, thickness)
        
        return screenshot
    
    def wait(self, seconds):
        """Wait for specified seconds"""
        logger.info(f"Waiting {seconds} seconds")
        time.sleep(seconds)