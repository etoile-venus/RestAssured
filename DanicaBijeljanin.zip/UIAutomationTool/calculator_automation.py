"""
Calculator automation using OpenCV template matching
"""

import subprocess
import time
import logging
from automation_library import ImageAutomation

logger = logging.getLogger(__name__)


class CalculatorImageAutomation(ImageAutomation):
    """Calculator automation using image recognition"""
    
    def __init__(self, templates_dir="templates/calculator", confidence=0.8):
        super().__init__(templates_dir, confidence)
        self.calculator_process = None
    
    def open_calculator(self):
        """Open Windows Calculator"""
        logger.info("Opening Calculator")
        try:
            self.calculator_process = subprocess.Popen(['calc.exe'])
            time.sleep(2)  # Wait for calculator to open
            
            # Verify calculator opened by looking for any number button
            if self.wait_for_template('button_1', timeout=5):
                logger.info("Calculator opened successfully")
                return True
            else:
                logger.error("Calculator did not open properly")
                return False
        except Exception as e:
            logger.error(f"Failed to open calculator: {e}")
            return False
    
    def close_calculator(self):
        """Close calculator"""
        logger.info("Closing Calculator")
        try:
            if self.calculator_process:
                self.calculator_process.terminate()
            # Alternative: close via Alt+F4
            self.hotkey('alt', 'F4')
            return True
        except Exception as e:
            logger.error(f"Failed to close calculator: {e}")
            return False
    
    def click_number(self, number):
        """
        Click a number button (0-9)
        Args:
            number: Number to click (0-9)
        """
        logger.info(f"Clicking number: {number}")
        template = f"button_{number}"
        return self.click_template(template)

    def click_operator(self, operator):
        """
        Click an operator button
        Args:
            operator: '+', '-', '*', '/', '='
        """
        logger.info(f"Clicking operator: {operator}")
        
        operator_map = {
            '+': 'button_plus',
            '-': 'button_minus',
            '*': 'button_multiply',
            '/': 'button_divide',
            '=': 'button_equals'
        }
        
        template = operator_map.get(operator)
        if template:
            return self.click_template(template)
        else:
            logger.error(f"Unknown operator: {operator}")
            return False
    
    def click_clear(self):
        """Click Clear (C) button"""
        logger.info("Clicking Clear")
        return self.click_template('button_clear')
    
    def click_clear_entry(self):
        """Click Clear Entry (CE) button"""
        logger.info("Clicking Clear Entry")
        return self.click_template('button_clear_entry')
    
    def click_decimal(self):
        """Click decimal point button"""
        logger.info("Clicking decimal point")
        return self.click_template('button_decimal')
    
    def perform_calculation(self, expression):
        """
        Perform a calculation by clicking buttons
        Args:
            expression: Math expression like "5+3" or "10*2"
        Returns:
            True if all clicks successful
        """
        logger.info(f"Performing calculation: {expression}")
        
        # Clear calculator first
        self.click_clear()
        time.sleep(0.3)
        
        # Parse and execute expression
        success = True
        for char in expression:
            if char.isdigit():
                if not self.click_number(char):
                    success = False
                    break
            elif char in ['+', '-', '*', '/']:
                if not self.click_operator(char):
                    success = False
                    break
            elif char == '.':
                if not self.click_decimal():
                    success = False
                    break
            time.sleep(0.2)
        
        # Click equals
        if success:
            self.click_operator('=')
            time.sleep(0.5)
        
        return success
    
    def verify_button_exists(self, button_name):
        """Verify a button exists on screen"""
        return self.verify_template_exists(button_name)