# Practical Assignment: Calculator Test Automation
## Template Matching & BDD Testing

## 🎯 Learning Objectives

By completing this assignment, you will demonstrate:
1. Understanding of template matching concepts
2. Ability to write BDD scenarios in Gherkin
3. Skills in creating automated UI tests
4. Problem-solving in test automation
5. Documentation and reporting skills

---

## 📦 Starter Package

### Project structure

```
calculator_automation_starter.zip
├── automation_library.py          ← Core library (provided)
├── calculator_automation.py       ← Calculator code (provided)  
├── template_helper.py             ← Template tool (provided)
├── requirements.txt               ← Dependencies (provided)
├── features/
│   ├── environment.py            ← Setup/teardown (provided)
│   ├── calculator.feature        ← TO COMPLETE
│   └── steps/
│       └── calculator_steps.py   ← TO COMPLETE
└── templates/
    └── calculator/               ← TO CREATE
```

### Initial Setup

**Step 1: Install dependencies**
```bash
pip install -r requirements.txt
```

**Step 2: Verify installation**
```bash
python -c "import cv2, behave, pyautogui; print('✓ All dependencies installed')"
```

---

## 📝 Part 1: Template Creation

### Task 1.1: Capture Calculator Buttons

**Required Templates (15 templates minimum):**

| Template Name | Description | Example |
|--------------|-------------|---------|
| `button_0.png` | Number zero | Image of "0" button |
| `button_1.png` | Number one | Image of "1" button |
| `button_2.png` | Number two | Image of "2" button |
| `button_3.png` | Number three | Image of "3" button |
| `button_4.png` | Number four | Image of "4" button |
| `button_5.png` | Number five | Image of "5" button |
| `button_6.png` | Number six | Image of "6" button |
| `button_7.png` | Number seven | Image of "7" button |
| `button_8.png` | Number eight | Image of "8" button |
| `button_9.png` | Number nine | Image of "9" button |
| `button_plus.png` | Addition | Image of "+" button |
| `button_minus.png` | Subtraction | Image of "−" button |
| `button_multiply.png` | Multiplication | Image of "×" button |
| `button_divide.png` | Division | Image of "÷" button |
| `button_equals.png` | Equals | Image of "=" button |

**Bonus Templates:**
- `button_clear.png` (C button)
- `button_clear_entry.png` (CE button)
- `button_decimal.png` (. button)
- `button_percent.png` (% button)

### Capture Methods

**Method A: Using Template Helper (Recommended)**
```bash
python template_creator.py
```
Follow the on-screen instructions.

**Method B: Manual Capture**
1. Open Calculator (`Win + R` → type `calc` → Enter)
2. Use Windows Snipping Tool (`Win + Shift + S`)
3. Capture each button individually
4. Save as PNG in `templates/calculator/`
5. Name files exactly as listed above

**Quality Checklist:**
- [ ] Button is centered in image
- [ ] No background shadows
- [ ] Image is not blurry
- [ ] Size is consistent (approximately 40-80 pixels)
- [ ] File format is PNG
- [ ] Filename matches exactly (case-sensitive)

## 📝 Part 2: BDD Scenarios

### Task 2.1: Complete Feature File

Open `features/calculator.feature` and complete it with **at least 10 scenarios**.

**Template:**
```gherkin
Feature: Windows Calculator Comprehensive Testing
  As a quality assurance engineer
  I want to test the Windows Calculator application
  So that I can ensure it performs calculations correctly

  Background:
    Given the Calculator application is open

  # ================================
  # SECTION 1: BASIC OPERATIONS
  # ================================

  Scenario: Add two single-digit numbers
    When I enter "5" plus "3"
    And I press equals
    Then the result should be "8"

  Scenario: Subtract two single-digit numbers
    # TODO: Complete this scenario
    # Test: 9 - 4 = 5

  Scenario: Multiply two single-digit numbers
    # TODO: Complete this scenario
    # Test: 7 × 6 = 42

  Scenario: Divide two single-digit numbers
    # TODO: Complete this scenario
    # Test: 8 ÷ 4 = 2

  # ================================
  # SECTION 2: MULTI-DIGIT OPERATIONS
  # ================================

  Scenario: Add two multi-digit numbers
    When I enter "123" plus "456"
    And I press equals
    Then the result should be "579"

  Scenario: Subtract multi-digit numbers
    # TODO: Complete this scenario
    # Test: 500 - 237 = 263

  # ================================
  # SECTION 3: DECIMAL OPERATIONS
  # ================================

  Scenario: Add decimal numbers
    # TODO: Complete this scenario
    # Test: 5.5 + 2.3 = 7.8
    # Hint: Use decimal point button

  # ================================
  # SECTION 4: CLEAR FUNCTIONALITY
  # ================================

  Scenario: Clear calculator after entering numbers
    When I click button "9"
    And I click button "9"
    And I click button "9"
    And I clear the calculator
    Then the calculator should be cleared

  # ================================
  # SECTION 5: CHAIN CALCULATIONS
  # ================================

  Scenario: Perform chain calculation
    When I enter "5" plus "3"
    And I press equals
    And I multiply "2"
    And I press equals
    Then the result should be "16"

  # ================================
  # SECTION 7: UI VERIFICATION
  # ================================

  Scenario: Verify number buttons are visible
    # TODO: Complete this scenario

  Scenario: Verify operator buttons are visible
    # TODO: Complete this scenario
```

### Task 2.2: Scenario Quality Guidelines

**Each scenario must:**
- ✅ Have a clear, descriptive name
- ✅ Be independent (not rely on other scenarios)
- ✅ Test one specific behavior
- ✅ Have clear Given-When-Then structure
- ✅ Use realistic test data

**Example - Good vs Bad:**

❌ **Bad Scenario:**
```gherkin
Scenario: Test calculator
  Given calculator
  When I click stuff
  Then it works
```

✅ **Good Scenario:**
```gherkin
Scenario: Calculate sum of two three-digit numbers
  Given the Calculator application is open
  When I enter "345" plus "678"
  And I press equals
  Then the result should be "1023"
```

## 📝 Part 3: Step Definitions

### Task 3.1: Implement Custom Step

Open `features/steps/calculator_steps.py` and implement these **2 required custom steps**:

#### Custom Step 1: Decimal Number Entry
```python
@when('I enter decimal number "{number}"')
def step_enter_decimal_number(context, number):
    """
    Enter a decimal number (e.g., "5.5", "10.75")
    
    Example usage:
        When I enter decimal number "5.5"
    
    Your implementation should:
    1. Split number by decimal point
    2. Click digits before decimal
    3. Click decimal point button
    4. Click digits after decimal
    """
    calc = context.calculator
    
    # TODO: Implement this function
    # Hint: Use string split() and loop through digits
    # Hint: Use calc.click_number(digit) and calc.click_decimal()
    
    pass  # Remove this and add your code
```

#### Custom Step 2: Chain Operation
```python
@when('I {operation} "{number}"')
def step_chain_operation(context, operation, number):
    """
    Perform operation on current result
    
    Example usage:
        When I multiply "2"
        When I plus "5"
    
    Your implementation should:
    1. Click the operator button
    2. Enter the number
    """
    calc = context.calculator
    
    # TODO: Implement this function
    # Hint: Map operation names to operators
    # operation_map = {'plus': '+', 'minus': '-', 'multiply': '*', 'divide': '/'}
    
    pass  # Remove this and add your code
```

### Task 3.2: Implementation Hints

**Hint for Decimal Numbers:**
```python
# Example approach:
number_parts = number.split('.')  # Split "5.5" into ["5", "5"]
# Click first part digits
# Click decimal button
# Click second part digits
```

**Hint for Chain Operations:**
```python
# Example approach:
operator_map = {
    'plus': '+',
    'minus': '-',
    'multiply': '*',
    'divide': '/'
}
operator_symbol = operator_map.get(operation.lower())
```

**Hint for Display Verification:**
```python
# Simple approach:
assert calc.verify_button_exists('button_equals'), "Calculator not responsive"

# Advanced approach (bonus):
# Use pytesseract to read display
# import pytesseract
# display_text = calc.get_display_value()
# assert text in display_text
```

## 📝 Part 4: Test Execution

### Task 4.1: Run All Tests

**Execute your test suite:**
```bash
# Run all tests
behave features/

# Run with verbose output
behave features/ --format pretty --no-capture

# Run specific scenario
behave features/calculator.feature --name "Add two single-digit numbers"
```

### Task 4.2: Generate Report

**Create HTML report:**
```bash
behave features/ --format html --outfile test_report.html
```

**Create JSON report:**
```bash
behave features/ --format json --outfile test_results.json
```

### Task 4.3: Document Results

Create `TEST_RESULTS.md`:
```markdown
# Test Execution Results

## Summary
- **Date**: [Your test date]
- **Duration**: [Total execution time]
- **Environment**: Windows 10/11, Python 3.x

## Test Statistics
- Total Scenarios: X
- Passed: X
- Failed: X
- Skipped: X
- Success Rate: X%

## Detailed Results

### Passed Scenarios
1. Add two single-digit numbers ✓
2. Subtract two single-digit numbers ✓
[... list all passed scenarios ...]

### Failed Scenarios (if any)
1. [Scenario name] ✗
   - **Error**: [Error message]
   - **Reason**: [Why it failed]
   - **Screenshot**: [filename.png]

## Issues Encountered
[Describe any problems and how you solved them]

## Observations
[Any interesting findings during testing]
```

### Task 4.4: Screenshots

Take screenshots of:
1. Test execution in terminal
2. HTML report opened in browser
3. Calculator during test execution
4. Any failed scenarios

Save in `screenshots/` folder.

## Running Tests

### Run All Tests
```bash
behave features/
```

### Run Specific Scenario
```bash
behave features/calculator.feature --name "Add two numbers"
```

### Generate HTML Report
```bash
behave features/ --format html --outfile report.html
```

## Test Scenarios

### Covered Functionality
- ✅ Basic arithmetic operations (add, subtract, multiply, divide)
- ✅ Multi-digit number calculations
- ✅ Decimal number calculations
- ✅ Chain calculations
- ✅ Clear functionality
- ✅ Button visibility verification

### Test Statistics
- **Total Scenarios**: [number]
- **Total Steps**: [number]
- **Execution Time**: [time]

## Template Matching Approach

This project uses OpenCV template matching to identify and interact with calculator buttons:

1. **Capture**: Screenshot of calculator
2. **Match**: Find button templates in screenshot
3. **Click**: Click at matched location
4. **Verify**: Confirm action completed

### Confidence Threshold
- Minimum match confidence: 80%
- Can be adjusted in calculator_automation.py

## Future Improvements
- [ ] OCR integration for result verification
- [ ] Support for additional calculator modes

## References
- OpenCV Documentation: https://docs.opencv.org/
- Behave Documentation: https://behave.readthedocs.io/
```

### Task 5.2: Code Comments

Add comments to your custom step definitions:

```python
@when('I enter decimal number "{number}"')
def step_enter_decimal_number(context, number):
    """
    Enter a decimal number by clicking digits and decimal point.
    
    Args:
        context: Behave context object
        number: Decimal number as string (e.g., "5.5")
    
    Process:
        1. Split number by decimal point
        2. Click each digit before decimal
        3. Click decimal point button
        4. Click each digit after decimal
    
    Example:
        When I enter decimal number "5.5"
        Result: Clicks 5, then ., then 5
    """
    # Your implementation with inline comments
    calc = context.calculator
    
    # Split the number into integer and decimal parts
    # ... your code ...
```

## 📝 Part 6: Project Quality

### Code Quality Checklist

- [ ] **No hardcoded paths** - Use relative paths
- [ ] **Error handling** - Try-except blocks where needed
- [ ] **Consistent naming** - Follow Python conventions
- [ ] **No unused imports** - Clean up imports
- [ ] **Proper indentation** - 4 spaces per level

### Project Organization Checklist

- [ ] All files in correct folders
- [ ] Template images are PNG format
- [ ] No unnecessary files (e.g., .pyc, __pycache__)
- [ ] Requirements.txt is accurate
- [ ] README.md is in root directory

## 🎁 Bonus Challenges

### Bonus 1: OCR Implementation

Implement real result verification using Tesseract OCR:

```python
import pytesseract

def get_display_value(self):
    """
    Read calculator display using OCR
    """
    # 1. Capture display region
    # 2. Preprocess image (grayscale, threshold)
    # 3. Run OCR
    # 4. Clean and return result
    pass
```

**Deliverables:**
- Working OCR implementation
- Updated step definition using OCR
- Documentation of OCR setup

## 📤 Submission Requirements

### What to Submit

**ZIP File**
1. Create ZIP of entire project folder
2. Name it: `[YourLastName]_[YourFirstName]_Calculator_Tests.zip`

### Folder Structure for Submission

```
[YourName]_Calculator_Tests/
├── automation_library.py
├── calculator_automation.py
├── template_helper.py
├── requirements.txt
├── README.md
├── TEST_RESULTS.md
├── test_report.html
├── templates/
│   └── calculator/
│       ├── button_0.png
│       ├── button_1.png
│       └── ... (all templates)
├── features/
│   ├── calculator.feature
│   ├── environment.py
│   └── steps/
│       └── calculator_steps.py
├── screenshots/
│   ├── test_execution.png
│   ├── html_report.png
│   └── ... (other screenshots)
└── bonus/ (if applicable)
    └── ... (bonus implementations)
```

### Pre-Submission Checklist

- [ ] All templates created (15+ files)
- [ ] Feature file complete (10+ scenarios)
- [ ] Custom steps implemented (3 steps)
- [ ] Tests execute successfully
- [ ] Reports generated (HTML)
- [ ] Screenshots included
- [ ] No errors in code
- [ ] requirements.txt accurate
- [ ] All files properly named

---

## ❓ FAQ

### Q: Can I use a different calculator application?
**A:** Yes, but Windows Calculator is recommended. If using another app, document the changes.

### Q: My tests run too fast, buttons not clicked?
**A:** Add `time.sleep(0.3)` delays between actions.

### Q: Template not found error?
**A:** Verify filename spelling, check file exists, ensure calculator is visible on screen.

### Q: Can I modify the provided library files?
**A:** You can extend them, but don't break existing functionality. Document all changes.

---

## 📞 Support

### Getting Help

1. **Check documentation**: Review tutorial and code comments
2. **Debug systematically**: Use print statements and logging
3. **Search online**: Stack Overflow, OpenCV docs

### Common Errors and Solutions

**Error: Module not found**
```bash
Solution: pip install [module_name]
```

**Error: Template not found**
```
Solution: Check templates/ folder, verify filename spelling
```

**Error: Calculator won't open**
```
Solution: Use full path 'C:\\Windows\\System32\\calc.exe'
```

**Error: Behave command not found**
```bash
Solution: pip install behave
# Or use: python -m behave features/
```

---